var mySwiper = new Swiper('.swiper-container', {
    slidesPerView:2,//how you see card in slider
    loop: true, //infinity
    navigation: {
        nextEl: '.arrow'//button next custom       
      },
});